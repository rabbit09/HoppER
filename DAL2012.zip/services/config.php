<?php
//config bd
mysql_connect('localhost','root','');
mysql_select_db('hopper');
?>