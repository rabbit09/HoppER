jQuery(document).ready(function($){
  $('#emergente').center();
});